CREATE TABLE `users` (
  `id` bigint PRIMARY KEY AUTO_INCREMENT,
  `name` varchar(255),
  `email` varchar(255) UNIQUE,
  `email_verified_at` datetime,
  `password` varchar(255),
  `remember_token` varchar(100),
  `created_at` datetime,
  `updated_at` datetime
);

CREATE TABLE `packages` (
  `id` integer PRIMARY KEY AUTO_INCREMENT,
  `package_name` varchar(255),
  `package_image` text,
  `price` decimal(10,2),
  `description` text,
  `status` varchar(50),
  `created_at` timestamp,
  `updated_at` timestamp,
  `deleted_at` timestamp
);

CREATE TABLE `bookings` (
  `id` integer PRIMARY KEY AUTO_INCREMENT,
  `user_id` bigint,
  `package_id` integer,
  `booking_date` date,
  `booking_time` time,
  `status` varchar(50) DEFAULT 'pending',
  `created_at` timestamp,
  `updated_at` timestamp,
  `user_name` varchar(255)
);

CREATE TABLE `payments` (
  `id` integer PRIMARY KEY AUTO_INCREMENT,
  `booking_id` integer,
  `payment_method` ENUM ('cash', 'bank_transfer'),
  `amount` decimal(10,2),
  `created_at` timestamp,
  `updated_at` timestamp
);

ALTER TABLE `bookings` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `bookings` ADD FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`);

ALTER TABLE `payments` ADD FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`);
